
.. automodule:: pygtkhelpers.delegates
    :members:

