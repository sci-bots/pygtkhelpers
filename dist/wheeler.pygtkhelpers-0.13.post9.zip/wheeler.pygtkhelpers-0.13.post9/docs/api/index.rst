
API
===

.. toctree::
    :maxdepth: 2

    delegates
    proxy
    forms
    utils
    gthreads
    objectlist
    widgets
    dialogs
    test
    debug




