
.. literalinclude:: ../../examples/forms.py

.. figure:: /media/simpleform.png

    The resulting form

.. image:: /media/pygtkhelpers_forms.png

.. automodule:: pygtkhelpers.forms
    :members:


