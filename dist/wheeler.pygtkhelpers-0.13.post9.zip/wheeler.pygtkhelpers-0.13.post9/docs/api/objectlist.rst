
.. automodule:: pygtkhelpers.ui.objectlist

    .. autoclass:: Column
        :members:

    .. autoclass:: ObjectList
        :members:
        :inherited-members:

    .. autoclass:: ObjectTree
        :members:
        :inherited-members:
