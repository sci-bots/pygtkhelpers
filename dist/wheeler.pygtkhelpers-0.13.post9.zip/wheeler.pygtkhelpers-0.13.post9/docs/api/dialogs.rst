
.. automodule:: pygtkhelpers.ui.dialogs
    :members:

