
Downloads
=========

You can install PyGTKHelpers by using easy_install or pip:

.. code-block:: bash

    easy_install pygtkhelpers

* `Visit our pypi page <http://pypi.python.org/pypi/pygtkhelpers/>`_ for
  available source distribution downloads


